import numpy as np
import pandas as pd
from flask import Flask, request, jsonify, render_template
import pickle
#flask app setup
app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))


#home route(/)
@app.route('/')
def home():
    return render_template('index.html')

#prediction route
@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    float_features = [float(x) for x in request.form.values()]
    final_features = [np.array(float_features)]
    prediction = model.predict( final_features )

    # if prediction==1:
    #     pred='POSITIVE CKD!!'
    # else:
    #     pred="NEGATIVE CKD..."
    output = prediction

    return render_template('index.html', prediction_text='{}'.format(output))
#running app
if __name__ == "__main__":
    app.run(debug=True)
